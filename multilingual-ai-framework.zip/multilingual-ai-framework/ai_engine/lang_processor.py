def detect_language(text): return "en"
def translate_to_english(text, source_lang): return text